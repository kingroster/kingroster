'use strict';
var a42_0x5aef4c = a42_0x2c5c;

function a42_0x2c5c(_0x898393, _0x5955b6) {
    var _0x533f11 = a42_0x533f();
    return a42_0x2c5c = function(_0x2c5c3b, _0x180e57) {
        _0x2c5c3b = _0x2c5c3b - 0x123;
        var _0x127bb6 = _0x533f11[_0x2c5c3b];
        return _0x127bb6;
    }, a42_0x2c5c(_0x898393, _0x5955b6);
}(function(_0x27eaee, _0x4ed72c) {
    var _0x5a3203 = a42_0x2c5c,
        _0x3a5830 = _0x27eaee();
    while (!![]) {
        try {
            var _0x691d30 = -parseInt(_0x5a3203(0x172)) / 0x1 * (-parseInt(_0x5a3203(0x1b3)) / 0x2) + parseInt(_0x5a3203(0x179)) / 0x3 + -parseInt(_0x5a3203(0x1c4)) / 0x4 * (parseInt(_0x5a3203(0x1be)) / 0x5) + parseInt(_0x5a3203(0x1c5)) / 0x6 * (-parseInt(_0x5a3203(0x1a6)) / 0x7) + parseInt(_0x5a3203(0x12a)) / 0x8 + parseInt(_0x5a3203(0x13a)) / 0x9 * (-parseInt(_0x5a3203(0x199)) / 0xa) + parseInt(_0x5a3203(0x181)) / 0xb;
            if (_0x691d30 === _0x4ed72c) break;
            else _0x3a5830['push'](_0x3a5830['shift']());
        } catch (_0x21708e) {
            _0x3a5830['push'](_0x3a5830['shift']());
        }
    }
}(a42_0x533f, 0x3f2bd));

function a42_0x533f() {
    var _0xd8ce6 = ['value', 'YYYY-MM-DD', 'location', '150kCrTrI', 'clear', 'isAdmin', 'webpackChunkfreelancer_waala', '/login', 'Error\x20fetching\x20data:', 'prev', 'Date\x20Wise\x20Closed\x20Leads', 'img', 'input\x20input-bordered\x20w-72', '/statistics/stats-count-by-date?startDate=', 'white', 'jsx', '182XbjJPW', 'stop', 'response', 'div', 'inline-block\x20', 'labelTitle', 'currentColor', '0\x200\x2024\x2024', 'true', 'text-2xl\x20md:text-3xl\x20text-center\x20font-bold\x20', 'Assign\x20additional\x20leads\x20to\x20HR\x20members\x20who\x20have\x20completed\x20their\x20current\x20assignments.', 'grid\x20lg:grid-cols-2\x20mt-4\x20grid-cols-1\x20gap-6', 'description', '270934reaBhF', 'wrap', 'stat-value\x20dark:text-slate-300\x20text-', 'span', 'rgb(53,\x20162,\x20235)', 'invisible', 'w-72', 'approvedAt', 'createElement', 'Total\x20Withdrawal\x20Amount', 'text-lg', '3590ROODne', 'count', 'Keep\x20an\x20eye\x20on\x20your\x20whatsapp\x20for\x20updates\x20on\x20your\x20verification\x20status.\x20We\x20will\x20notify\x20you\x20promptly\x20once\x20your\x20account\x20has\x20been\x20successfully\x20verified.', 'href', 'hero-content\x20py-12', 'target', '136nFHqee', '104268zGbyNq', 'getItem', 'leads-', 'styleClass', 'startOf', 'format', 'Let\x27s\x20work\x20together\x20to\x20achieve\x20greatness!\x20🚀', '\x20If,\x20by\x20any\x20chance,\x20your\x20account\x20is\x20not\x20verified\x20within\x20the\x20stipulated\x20time,\x20or\x20if\x20you\x20have\x20any\x20urgent\x20queries,\x20feel\x20free\x20to\x20reach\x20out\x20to\x20our\x20admin\x20team.', 'light', 'stat', 'Welcome\x20to\x20', 'list-decimal\x20pl-6\x20mb-4', 'totalClosedLeadCount', '\x20🌟', 'maxValue', 'font-bold\x20text-rose-500\x20dark:text-red-400', 'Team\x20Leader', 'Count:\x20', 'maxLength', 'round', 'M15\x2012a3\x203\x200\x2011-6\x200\x203\x203\x200\x20016\x200z', 'withdrawalDateWiseData', 'get', 'Withdrawals', 'teamLeaderName', 'test', 'concat', 'topMargin', 'map', 'withdrawalDateWiseData\x20is\x20', 'w-48\x20inline-block', '\x20today!\x20Get\x20Started', 'date', 'children', 'closedLeadDateWiseData', '1179768UtFVbg', 'font-bold\x20text-green-700\x20dark:text-green-300', '\x20Contacting\x20Admin:', 'http://www.w3.org/2000/svg', 'text-center\x20\x20text-error\x20', 'text-sm\x20mt-4', 'endDate', 'Reset\x20passwords\x20for\x20HR\x20members\x20who\x20have\x20forgotten\x20them.', 'status', 'titleId', 'Review\x20the\x20number\x20of\x20leads\x20each\x20HR\x20has\x20called\x20and\x20assess\x20their\x20performance.', 'role', 'Password', 'text-2xl\x20mt-8\x20font-bold', 'M3.98\x208.223A10.477\x2010.477\x200\x20001.934\x2012C3.226\x2016.338\x207.244\x2019.5\x2012\x2019.5c.993\x200\x201.953-.138\x202.863-.395M6.228\x206.228A10.45\x2010.45\x200\x200112\x204.5c4.756\x200\x208.773\x203.162\x2010.065\x207.498a10.523\x2010.523\x200\x2001-4.293\x205.774M6.228\x206.228L3\x203m3.228\x203.228l3.65\x203.65m7.894\x207.894L21\x2021m-3.228-3.228l-3.65-3.65m0\x200a3\x203\x200\x2010-4.243-4.243m4.242\x204.242L9.88\x209.88', 'useMemo', '223389pfxwGt', 'inline-block\x20float-right', 'toUpperCase', 'type', 'text-lg\x20font-semibold\x20mb-4', 'push', 'Total\x20User\x20Count', 'Leads', ',\x20We\x20are\x20thrilled\x20to\x20have\x20you\x20on\x20board!\x20As\x20part\x20of\x20our\x20commitment\x20to\x20efficiency\x20and\x20excellence,\x20we\x20have\x20outlined\x20the\x20following\x20important\x20procedures\x20for\x20your\x20daily\x20operations:', 'containerStyle', 'top', 'jsxs', 'stat-desc\x20\x20', 'strong', 'totalWithdrawalAmount', 'Total\x20Days', '🌟\x20Welcome\x20to\x20', 'error', 'input\x20input-bordered\x20w-full\x20', 'text-lg\x20mt-6', 'label', 'Withdraw\x20leads\x20from\x20HR\x20members\x20who\x20are\x20not\x20actively\x20working.', 'w-8\x20h-8', 'text-center', 'M2.036\x2012.322a1.012\x201.012\x200\x20010-.639C3.423\x207.51\x207.36\x204.5\x2012\x204.5c4.638\x200\x208.573\x203.007\x209.963\x207.178.07.207.07.431\x200\x20.639C20.577\x2016.49\x2016.64\x2019.5\x2012\x2019.5c-4.638\x200-8.573-3.007-9.963-7.178z', 'users-', 'userDateWiseData', 'assign', 'withdrawals-', 'down', '\x20Leads\x20will\x20be\x20assigned\x20based\x20on\x20your\x20punctual\x20attendance.\x20Make\x20sure\x20to\x20regularly\x20check\x20the\x20lead\x20dashboard\x20to\x20stay\x20updated\x20on\x20your\x20assigned\x20leads.\x20Leads\x20are\x20an\x20integral\x20part\x20of\x20our\x20success,\x20and\x20your\x20dedication\x20is\x20key\x20to\x20achieving\x20our\x20goals.\x20If\x20you\x20have\x20any\x20concerns\x20or\x20need\x20assistance,\x20please\x20reach\x20out\x20to\x20your\x20team\x20leader,\x20', '\x20Please\x20ensure\x20you\x20mark\x20your\x20attendance\x20promptly\x20between\x2005:00\x20AM\x20and\x2010:00\x20AM\x20daily.\x20This\x20is\x20crucial\x20for\x20lead\x20assignment\x20and\x20maintaining\x20team\x20coordination.\x20Late\x20attendance\x20may\x20impact\x20lead\x20allocation.\x20If\x20you\x20encounter\x20any\x20issues\x20or\x20have\x20questions,\x20feel\x20free\x20to\x20contact\x20your\x20team\x20leader,', 'Verification\x20Process:', 'Attendance\x20Marking:', 'grid\x20lg:grid-cols-4\x20mt-2\x20md:grid-cols-2\x20grid-cols-1\x20gap-6', 'bg-base-100\x20\x20p-6\x20rounded-lg\x20shadow-lg', 'minValue', '\x20Patience\x20is\x20Key:', 'none', 'useEffect', 'Total\x20Closed\x20Lead\x20Count', 'icon', 'text-xl\x20font-semibold\x20', 'updateFormValue', 'mt-6', 'totalDays', 'Dear', 'h-full\x20w-full\x20pb-6\x20bg-base-100', 'Data\x20coming\x20into\x20LineChart:', 'path', 'startDate', 'next', '\x20As\x20a\x20new\x20joiner,\x20your\x20account\x20is\x20currently\x20in\x20the\x20verification\x20stage.\x20Our\x20administration\x20team\x20is\x20diligently\x20working\x20to\x20verify\x20your\x20details\x20within\x20the\x20next\x2024\x20hours.', 'primary', 'number', 'data', '3VjxGwL', 'We\x20are\x20thrilled\x20to\x20have\x20you\x20on\x20board\x20and\x20look\x20forward\x20to\x20your\x20valuable\x20contributions\x20to\x20our\x20team.\x20As\x20you\x20embark\x20on\x20this\x20exciting\x20journey\x20with\x20us,\x20please\x20note\x20the\x20following\x20important\x20information\x20regarding\x20the\x20verification\x20process:', 'title', 'resukt\x20is\x20', 'text-center\x20mt-8', 'Best\x20regards,\x20', 'raw', '1506984MBvPkH', '\x20Leads\x20Management', 'TopSideButtons', 'useState', 'disabled', './new_year.gif', 'Date\x20Wise\x20User\x20Count', 'Ready\x20to\x20transform\x20leads\x20into\x20success?\x20Dive\x20into\x20your\x20daily\x20tasks,\x20make\x20those\x20calls,\x20and\x20celebrate\x20your\x20victories!\x20Check\x20out\x20your\x20profile\x20along\x20the\x20way.', '562144grYcUU', 'defaultValue', 'No\x20data\x20available\x20for\x20the\x20selected\x20date\x20range.', 'mb-2', 'Queries\x20and\x20Support:', 'hero\x20min-h-full\x20rounded-l-xl\x20bg-base-200', 'Manage\x20HR\x20statuses:\x20if\x20someone\x20is\x20not\x20working\x20or\x20on\x20leave,\x20update\x20their\x20status\x20to\x20hold\x20or\x20dead.', 'text-base\x20mb-4', '/logo192.png', 'includes', 'svg', 'endOf', 'Date\x20Wise\x20Withdrawal\x20Amount', 'day', 'Daily\x20Check-In:', 'placeholder', '-logo', 'forwardRef', '\x20If\x20you\x20have\x20any\x20questions,\x20concerns,\x20or\x20require\x20support,\x20please\x20do\x20not\x20hesitate\x20to\x20reach\x20out\x20to\x20the\x20admin\x20team.\x20We\x20are\x20here\x20to\x20assist\x20you\x20in\x20any\x20way\x20we\x20can.', 'totalUserCount', 'pr-8'];
    a42_0x533f = function() {
        return _0xd8ce6;
    };
    return a42_0x533f();
}(self[a42_0x5aef4c(0x19c)] = self['webpackChunkfreelancer_waala'] || [])[a42_0x5aef4c(0x13f)]([
    [0x1dc5], {
        0xc96: function(_0x5d553a, _0x1e3ebc, _0x5e39b0) {
            _0x5e39b0['d'](_0x1e3ebc, {
                'Z': function() {
                    return _0x2be1d4;
                }
            });
            var _0x517fa1 = _0x5e39b0(0x1911),
                _0x511aae = function(_0x1e1211) {
                    var _0x57684b = a42_0x2c5c,
                        _0x1b6465 = _0x1e1211['styleClass'],
                        _0x3a4c33 = _0x1e1211[_0x57684b(0x128)];
                    return (0x0, _0x517fa1[_0x57684b(0x1a5)])(_0x57684b(0x1a9), {
                        'className': _0x57684b(0x164)['concat'](_0x1b6465),
                        'children': _0x3a4c33
                    });
                },
                _0x2be1d4 = function(_0x2e707c) {
                    var _0x407889 = a42_0x2c5c,
                        _0x1cefde = _0x2e707c[_0x407889(0x174)],
                        _0x3b6af9 = _0x2e707c[_0x407889(0x128)],
                        _0x56201c = _0x2e707c[_0x407889(0x1e0)],
                        _0x2161c5 = _0x2e707c[_0x407889(0x17b)];
                    return (0x0, _0x517fa1[_0x407889(0x145)])('div', {
                        'className': 'card\x20w-full\x20p-6\x20bg-base-100\x20shadow-xl\x20' + (_0x56201c || _0x407889(0x166)),
                        'children': [(0x0, _0x517fa1[_0x407889(0x145)])(_0x511aae, {
                            'styleClass': _0x2161c5 ? _0x407889(0x1aa) : '',
                            'children': [_0x1cefde, _0x2161c5 && (0x0, _0x517fa1[_0x407889(0x1a5)])('div', {
                                'className': _0x407889(0x13b),
                                'children': _0x2161c5
                            })]
                        }), (0x0, _0x517fa1[_0x407889(0x1a5)])(_0x407889(0x1a9), {
                            'className': 'divider\x20mt-2'
                        }), (0x0, _0x517fa1[_0x407889(0x1a5)])(_0x407889(0x1a9), {
                            'className': _0x407889(0x169),
                            'children': _0x3b6af9
                        })]
                    });
                };
        },
        0x407: function(_0x1b116a, _0x4fdfe1, _0x33af96) {
            var _0x5347cc = _0x33af96(0x24df),
                _0xbda9a2 = _0x33af96(0x1c91),
                _0x414281 = _0x33af96(0x1911);
            _0x4fdfe1['Z'] = function(_0x403609) {
                var _0x203e2b = a42_0x2c5c,
                    _0x491b9f = _0x403609[_0x203e2b(0x1ab)],
                    _0x5510b6 = _0x403609['labelStyle'],
                    _0x58d5d4 = _0x403609[_0x203e2b(0x13d)],
                    _0x192e43 = _0x403609[_0x203e2b(0x143)],
                    _0x119cf6 = _0x403609[_0x203e2b(0x182)],
                    _0x3e263c = _0x403609[_0x203e2b(0x190)],
                    _0x1eb72d = _0x403609[_0x203e2b(0x165)],
                    _0x57a31b = _0x403609['updateType'],
                    _0x111a34 = _0x403609[_0x203e2b(0x1d3)],
                    _0x47c018 = _0x403609[_0x203e2b(0x15e)],
                    _0x2c58d3 = _0x403609[_0x203e2b(0x17d)],
                    _0x75cb78 = _0x403609[_0x203e2b(0x1d7)],
                    _0x5a865e = (0x0, _0xbda9a2[_0x203e2b(0x17c)])(''),
                    _0x22c96a = (0x0, _0x5347cc['Z'])(_0x5a865e, 0x2),
                    _0x5e55be = _0x22c96a[0x0],
                    _0x1b36bf = _0x22c96a[0x1];
                return (0x0, _0xbda9a2[_0x203e2b(0x161)])(function() {
                    _0x1b36bf(_0x119cf6);
                }, [_0x119cf6]), (0x0, _0x414281[_0x203e2b(0x145)])(_0x203e2b(0x1a9), {
                    'className': 'form-control\x20w-full\x20' [_0x203e2b(0x1df)](_0x192e43),
                    'children': [(0x0, _0x414281[_0x203e2b(0x1a5)])(_0x203e2b(0x14e), {
                        'className': _0x203e2b(0x14e),
                        'children': (0x0, _0x414281[_0x203e2b(0x1a5)])(_0x203e2b(0x1b6), {
                            'className': 'label-text\x20text-base-content\x20' + _0x5510b6,
                            'children': _0x491b9f
                        })
                    }), (0x0, _0x414281[_0x203e2b(0x1a5)])('input', {
                        'type': _0x58d5d4 || 'text',
                        'value': _0x5e55be,
                        'placeholder': _0x3e263c || '',
                        'onChange': function(_0x1e2f6d) {
                            var _0x3eb99d = _0x203e2b;
                            return _0x19e810 = _0x1e2f6d[_0x3eb99d(0x1c3)][_0x3eb99d(0x196)], void(_0x3eb99d(0x170) === _0x58d5d4 && _0x19e810['length'] > _0x75cb78 || (_0x3eb99d(0x170) !== _0x58d5d4 || /^\d*$/ [_0x3eb99d(0x1de)](_0x19e810)) && (_0x1b36bf(_0x19e810), _0x1eb72d({
                                'updateType': _0x57a31b,
                                'value': _0x19e810
                            })));
                            var _0x19e810;
                        },
                        'className': _0x203e2b(0x14c)['concat'](_0x203e2b(0x136) === _0x491b9f ? _0x203e2b(0x195) : ''),
                        'disabled': _0x2c58d3,
                        'max': _0x111a34,
                        'min': _0x47c018,
                        'maxLength': _0x75cb78
                    })]
                });
            };
        },
        0x365: function(_0x2c531c, _0x37d660, _0x2c640e) {
            var _0x15a821 = _0x2c640e(0x1911);
            _0x37d660['Z'] = function(_0x249d27) {
                var _0x6d08d0 = a42_0x2c5c,
                    _0x2a25ae = _0x249d27[_0x6d08d0(0x1c8)],
                    _0x20c7a9 = _0x249d27[_0x6d08d0(0x128)];
                return (0x0, _0x15a821[_0x6d08d0(0x1a5)])('p', {
                    'className': _0x6d08d0(0x12e)[_0x6d08d0(0x1df)](_0x2a25ae),
                    'children': _0x20c7a9
                });
            };
        },
        0x1071: function(_0x25b37d, _0x4f6050, _0x514dd2) {
            var _0x221b44 = _0x514dd2(0x1911);
            _0x4f6050['Z'] = function(_0x492684) {
                var _0x533228 = a42_0x2c5c,
                    _0x25e3b3 = _0x492684[_0x533228(0x174)],
                    _0xed4416 = _0x492684['icon'],
                    _0x55a814 = _0x492684[_0x533228(0x196)],
                    _0x4c83bd = _0x492684[_0x533228(0x1b2)],
                    _0x125269 = _0x492684['colorIndex'],
                    _0x33cc49 = [_0x533228(0x16f), _0x533228(0x16f)];
                return (0x0, _0x221b44[_0x533228(0x1a5)])('div', {
                    'className': 'stats\x20shadow',
                    'children': (0x0, _0x221b44[_0x533228(0x145)])(_0x533228(0x1a9), {
                        'className': _0x533228(0x1ce),
                        'children': [(0x0, _0x221b44['jsx'])('div', {
                            'className': 'stat-figure\x20dark:text-slate-300\x20text-' ['concat'](_0x33cc49[_0x125269 % 0x2]),
                            'children': _0xed4416
                        }), (0x0, _0x221b44[_0x533228(0x1a5)])('div', {
                            'className': 'stat-title\x20dark:text-slate-300',
                            'children': _0x25e3b3
                        }), (0x0, _0x221b44[_0x533228(0x1a5)])(_0x533228(0x1a9), {
                            'className': _0x533228(0x1b5)[_0x533228(0x1df)](_0x33cc49[_0x125269 % 0x2]),
                            'children': _0x55a814
                        }), (0x0, _0x221b44[_0x533228(0x1a5)])('div', {
                            'className': _0x533228(0x146) + (null !== _0x4c83bd && void 0x0 !== _0x4c83bd && _0x4c83bd[_0x533228(0x18a)]('↗︎') ? _0x533228(0x12b) : null !== _0x4c83bd && void 0x0 !== _0x4c83bd && _0x4c83bd[_0x533228(0x18a)]('↙') ? _0x533228(0x1d4) : ''),
                            'children': _0x4c83bd
                        })]
                    })
                });
            };
        },
        0x1c30: function(_0xc5cd26, _0x11715, _0x409902) {
            var _0x3badfc = _0x409902(0x1c91),
                _0xadea9f = _0x409902(0x1a50),
                _0x52c184 = _0x409902(0x166f),
                _0x452567 = _0x409902(0xc96),
                _0x59c3ab = _0x409902(0x1911);
            _0xadea9f['kL']['register'](_0xadea9f['uw'], _0xadea9f['f$'], _0xadea9f['od'], _0xadea9f['jn'], _0xadea9f['Dx'], _0xadea9f['u'], _0xadea9f['Gu'], _0xadea9f['De']), _0x11715['Z'] = function(_0x39dc9a) {
                var _0x3658ef = a42_0x2c5c,
                    _0x30ecad = _0x39dc9a[_0x3658ef(0x171)],
                    _0x4b69df = _0x39dc9a['title'],
                    _0x5e39bf = _0x39dc9a[_0x3658ef(0x14e)];
                console['log'](_0x3658ef(0x16a), _0x30ecad);
                var _0x1a303a = (0x0, _0x3badfc[_0x3658ef(0x139)])(function() {
                        var _0x1d82f = _0x3658ef,
                            _0x549e4a = null === _0x30ecad || void 0x0 === _0x30ecad ? void 0x0 : _0x30ecad['map'](function(_0x54ec29) {
                                var _0x35f210 = a42_0x2c5c;
                                return _0x54ec29[_0x35f210(0x127)];
                            }),
                            _0x3dd9c7 = null === _0x30ecad || void 0x0 === _0x30ecad ? void 0x0 : _0x30ecad[_0x1d82f(0x123)](function(_0x4cf093) {
                                var _0xa5dea9 = _0x1d82f;
                                return _0x4cf093[_0xa5dea9(0x1bf)];
                            });
                        return {
                            'labels': _0x549e4a,
                            'datasets': [{
                                'fill': !0x0,
                                'label': _0x5e39bf,
                                'data': _0x3dd9c7,
                                'borderColor': _0x1d82f(0x1b7),
                                'backgroundColor': 'rgba(53,\x20162,\x20235,\x200.5)'
                            }]
                        };
                    }, [_0x30ecad, _0x5e39bf]),
                    _0x4e3891 = (0x0, _0x3badfc[_0x3658ef(0x139)])(function() {
                        var _0x2ae539 = _0x3658ef;
                        return {
                            'responsive': !0x0,
                            'plugins': {
                                'legend': {
                                    'position': _0x2ae539(0x144)
                                },
                                'tooltip': {
                                    'callbacks': {
                                        'label': function(_0x55ef7d) {
                                            var _0x4754fc = _0x2ae539;
                                            return _0x4754fc(0x1d6)['concat'](_0x55ef7d[_0x4754fc(0x178)]);
                                        }
                                    }
                                }
                            }
                        };
                    }, []);
                return (0x0, _0x59c3ab[_0x3658ef(0x1a5)])(_0x452567['Z'], {
                    'title': _0x4b69df,
                    'children': (0x0, _0x59c3ab[_0x3658ef(0x1a5)])(_0x52c184['x1'], {
                        'data': _0x1a303a,
                        'options': _0x4e3891
                    })
                });
            };
        },
        0x143f: function(_0x21ddb2, _0x50bd64, _0x49fcf0) {
            var _0x40a858 = _0x49fcf0(0x70d),
                _0x452275 = _0x49fcf0(0x151d),
                _0x12f76b = _0x49fcf0(0x1911);
            _0x50bd64['Z'] = function() {
                var _0x1a1fda = a42_0x2c5c;
                return (0x0, _0x12f76b[_0x1a1fda(0x1a5)])(_0x1a1fda(0x1a9), {
                    'className': _0x1a1fda(0x186),
                    'children': (0x0, _0x12f76b[_0x1a1fda(0x1a5)])(_0x1a1fda(0x1a9), {
                        'className': _0x1a1fda(0x1c2),
                        'children': (0x0, _0x12f76b['jsxs'])(_0x1a1fda(0x1a9), {
                            'className': 'max-w-md',
                            'children': [(0x0, _0x12f76b[_0x1a1fda(0x145)])('h1', {
                                'className': _0x1a1fda(0x1af),
                                'children': [(0x0, _0x12f76b[_0x1a1fda(0x1a5)])(_0x1a1fda(0x1a1), {
                                    'src': _0x1a1fda(0x189),
                                    'className': 'w-12\x20h-12\x20object-contain\x20inline-block\x20mr-2\x20mask\x20mask-circle',
                                    'alt': '' [_0x1a1fda(0x1df)](_0x40a858['De'], _0x1a1fda(0x191))
                                }), _0x40a858['As']]
                            }), (0x0, _0x12f76b['jsx'])(_0x1a1fda(0x1a9), {
                                'className': _0x1a1fda(0x176),
                                'children': (0x0, _0x12f76b[_0x1a1fda(0x1a5)])(_0x1a1fda(0x1a1), {
                                    'src': _0x1a1fda(0x17e),
                                    'alt': '' [_0x1a1fda(0x1df)](_0x40a858['As'], _0x1a1fda(0x17a)),
                                    'className': _0x1a1fda(0x125)
                                })
                            }), (0x0, _0x12f76b[_0x1a1fda(0x1a5)])(_0x452275['Z'], {})]
                        })
                    })
                });
            };
        },
        0x151d: function(_0x4ba282, _0x15cbf5, _0x55824d) {
            var _0xe11521 = a42_0x5aef4c;
            _0x55824d['d'](_0x15cbf5, {
                'Z': function() {
                    return _0x152ce3;
                }
            });
            var _0x3a721a = _0x55824d(0x70d),
                _0x5a6ee2 = _0x55824d(0x1045),
                _0xd1c01b = _0x55824d(0x16e5),
                _0x21207b = _0x55824d(0x24df),
                _0x45dcb9 = _0x55824d(0x1c91),
                _0x515a82 = _0x55824d(0x1950),
                _0x2be5f6 = _0x55824d(0x330),
                _0x267be3 = _0x55824d['n'](_0x2be5f6),
                _0x3fdc2c = _0x55824d(0x11ac),
                _0x42f670 = _0x55824d(0x1c30),
                _0x34fb08 = _0x55824d(0x2cc),
                _0x185e2d = _0x55824d(0xcaa),
                _0xeaba9d = _0x55824d(0x1fb5),
                _0x378901 = _0x55824d(0x16b5),
                _0x3d4c12 = _0x55824d(0x1071),
                _0x545e4c = _0x55824d(0x2202),
                _0x5f425f = _0x55824d(0x1911),
                _0x42219e = function() {
                    var _0x28e73d = a42_0x2c5c,
                        _0xf243dd = (0x0, _0x45dcb9[_0x28e73d(0x17c)])({
                            'startDate': _0x267be3()()[_0x28e73d(0x1c9)]('day')['format']('YYYY-MM-DD'),
                            'endDate': _0x267be3()()[_0x28e73d(0x18c)](_0x28e73d(0x18e))[_0x28e73d(0x1ca)](_0x28e73d(0x197))
                        }),
                        _0x175bf7 = (0x0, _0x21207b['Z'])(_0xf243dd, 0x2),
                        _0x5e4a18 = _0x175bf7[0x0],
                        _0x4166c1 = _0x175bf7[0x1],
                        _0x3aff6c = (0x0, _0x45dcb9['useState'])(null),
                        _0x3ca100 = (0x0, _0x21207b['Z'])(_0x3aff6c, 0x2),
                        _0x1a64a4 = _0x3ca100[0x0],
                        _0x549cc6 = _0x3ca100[0x1],
                        _0x3fddaa = (function() {
                            var _0x21e148 = (0x0, _0xd1c01b['Z'])((0x0, _0x5a6ee2['Z'])()['mark'](function _0x580c5e(_0x5240db, _0x1d6ba1) {
                                var _0x22af9e = a42_0x2c5c,
                                    _0x6654d5, _0x35c966;
                                return (0x0, _0x5a6ee2['Z'])()[_0x22af9e(0x1b4)](function(_0x2cc4b3) {
                                    var _0x37d0f7 = _0x22af9e;
                                    for (;;) switch (_0x2cc4b3[_0x37d0f7(0x19f)] = _0x2cc4b3[_0x37d0f7(0x16d)]) {
                                        case 0x0:
                                            return _0x2cc4b3[_0x37d0f7(0x19f)] = 0x0, _0x2cc4b3[_0x37d0f7(0x16d)] = 0x3, _0x515a82['ZP'][_0x37d0f7(0x1db)]('' [_0x37d0f7(0x1df)](_0x3a721a['bl'], _0x37d0f7(0x1a3))[_0x37d0f7(0x1df)](_0x5240db, '&endDate=')[_0x37d0f7(0x1df)](_0x1d6ba1), _0x3a721a['E0']);
                                        case 0x3:
                                            _0x6654d5 = _0x2cc4b3['sent'], _0x35c966 = _0x6654d5[_0x37d0f7(0x171)], console['log'](_0x37d0f7(0x175), _0x35c966), _0x549cc6(_0x35c966 || null), _0x2cc4b3['next'] = 0xe;
                                            break;
                                        case 0x9:
                                            _0x2cc4b3[_0x37d0f7(0x19f)] = 0x9, _0x2cc4b3['t0'] = _0x2cc4b3['catch'](0x0), console[_0x37d0f7(0x14b)](_0x37d0f7(0x19e), _0x2cc4b3['t0']), _0x549cc6(null), (0x0, _0x545e4c['S'])(_0x2cc4b3['t0']);
                                        case 0xe:
                                        case 'end':
                                            return _0x2cc4b3[_0x37d0f7(0x1a7)]();
                                    }
                                }, _0x580c5e, null, [
                                    [0x0, 0x9]
                                ]);
                            }));
                            return function(_0x43c9e3, _0x153419) {
                                return _0x21e148['apply'](this, arguments);
                            };
                        }());
                    (0x0, _0x45dcb9['useEffect'])(function() {
                        var _0x42876a = _0x28e73d;
                        _0x5e4a18[_0x42876a(0x16c)] && _0x5e4a18[_0x42876a(0x130)] && _0x3fddaa(_0x5e4a18[_0x42876a(0x16c)], _0x5e4a18[_0x42876a(0x130)]);
                    }, [_0x5e4a18]);
                    var _0x25223e = [{
                            'title': _0x28e73d(0x149),
                            'value': (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x167)]) || 0x0,
                            'icon': (0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x34fb08['Z'], {
                                'className': _0x28e73d(0x150)
                            })
                        }, {
                            'title': _0x28e73d(0x140),
                            'value': (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x194)]) || 0x0,
                            'icon': (0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x185e2d['Z'], {
                                'className': _0x28e73d(0x150)
                            })
                        }, {
                            'title': _0x28e73d(0x162),
                            'value': (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x1d1)]) || 0x0,
                            'icon': (0x0, _0x5f425f['jsx'])(_0xeaba9d['Z'], {
                                'className': _0x28e73d(0x150)
                            })
                        }, {
                            'title': _0x28e73d(0x1bc),
                            'value': (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x148)]) || 0x0,
                            'icon': (0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x378901['Z'], {
                                'className': _0x28e73d(0x150)
                            })
                        }],
                        _0x14e27f = (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x154)]) || [],
                        _0x20d126 = (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x129)]) || [],
                        _0x3441bf = (null === _0x1a64a4 || void 0x0 === _0x1a64a4 ? void 0x0 : _0x1a64a4[_0x28e73d(0x1da)]) || [];
                    return console['log'](_0x28e73d(0x124), _0x3441bf), (0x0, _0x5f425f['jsxs'])(_0x28e73d(0x1a9), {
                        'children': [(0x0, _0x5f425f['jsx'])(_0x3fdc2c['Z'], {
                            'containerClassName': _0x28e73d(0x1b9),
                            'value': _0x5e4a18,
                            'theme': _0x28e73d(0x1cd),
                            'inputClassName': _0x28e73d(0x1a2),
                            'popoverDirection': _0x28e73d(0x157),
                            'toggleClassName': _0x28e73d(0x1b8),
                            'onChange': function(_0x3eac00) {
                                var _0x5a6d41 = _0x28e73d;
                                _0x3eac00[_0x5a6d41(0x16c)] && _0x3eac00[_0x5a6d41(0x130)] && _0x4166c1(_0x3eac00);
                            },
                            'showShortcuts': !0x0,
                            'primaryColor': _0x28e73d(0x1a4)
                        }), (0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x28e73d(0x1a9), {
                            'className': _0x28e73d(0x15c),
                            'children': _0x25223e[_0x28e73d(0x123)](function(_0x1f992b, _0x5ac5f9) {
                                var _0x4ad527 = _0x28e73d;
                                return (0x0, _0x5f425f['jsx'])(_0x3d4c12['Z'], {
                                    'title': _0x1f992b['title'],
                                    'icon': _0x1f992b[_0x4ad527(0x163)],
                                    'value': _0x1f992b[_0x4ad527(0x196)],
                                    'colorIndex': _0x5ac5f9
                                }, _0x5ac5f9);
                            })
                        }), _0x1a64a4 ? (0x0, _0x5f425f['jsxs'])('div', {
                            'className': _0x28e73d(0x1b1),
                            'children': [(0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x42f670['Z'], {
                                'data': _0x14e27f,
                                'label': 'Users',
                                'title': _0x28e73d(0x17f)
                            }, _0x28e73d(0x153)[_0x28e73d(0x1df)](_0x5e4a18[_0x28e73d(0x16c)], '-')[_0x28e73d(0x1df)](_0x5e4a18[_0x28e73d(0x130)])), (0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x42f670['Z'], {
                                'data': _0x20d126,
                                'label': _0x28e73d(0x141),
                                'title': _0x28e73d(0x1a0)
                            }, _0x28e73d(0x1c7)[_0x28e73d(0x1df)](_0x5e4a18[_0x28e73d(0x16c)], '-')['concat'](_0x5e4a18[_0x28e73d(0x130)])), (0x0, _0x5f425f[_0x28e73d(0x1a5)])(_0x42f670['Z'], {
                                'data': _0x3441bf,
                                'label': _0x28e73d(0x1dc),
                                'title': _0x28e73d(0x18d)
                            }, _0x28e73d(0x156)[_0x28e73d(0x1df)](_0x5e4a18[_0x28e73d(0x16c)], '-')[_0x28e73d(0x1df)](_0x5e4a18[_0x28e73d(0x130)]))]
                        }) : (0x0, _0x5f425f[_0x28e73d(0x1a5)])('p', {
                            'className': _0x28e73d(0x151),
                            'children': _0x28e73d(0x183)
                        })]
                    });
                },
                _0x1ed6ca = (0x0, _0x3a721a['is'])(),
                _0x177cc7 = localStorage[_0xe11521(0x1c6)]('accessToken'),
                _0x152ce3 = function() {
                    var _0x244184 = _0xe11521,
                        _0x47dbeb, _0x18024d;
                    return (0x0, _0x5f425f[_0x244184(0x1a5)])(_0x5f425f['Fragment'], {
                        'children': _0x177cc7 ? null !== _0x1ed6ca && void 0x0 !== _0x1ed6ca && _0x1ed6ca[_0x244184(0x19b)] ? (0x0, _0x5f425f['jsx'])(_0x5f425f['Fragment'], {
                            'children': (0x0, _0x5f425f[_0x244184(0x1a5)])(_0x42219e, {})
                        }) : null !== _0x1ed6ca && void 0x0 !== _0x1ed6ca && _0x1ed6ca[_0x244184(0x1ba)] ? (0x0, _0x5f425f['jsx'])(_0x5f425f['Fragment'], {
                            'children': (0x0, _0x5f425f[_0x244184(0x145)])('div', {
                                'className': _0x244184(0x15d),
                                'children': [(0x0, _0x5f425f['jsxs'])('p', {
                                    'className': 'text-lg\x20font-semibold\x20mb-4',
                                    'children': [_0x244184(0x14a), (0x0, _0x5f425f[_0x244184(0x145)])(_0x244184(0x147), {
                                        'children': [_0x3a721a['As'], '!']
                                    }), '\x20🌟']
                                }), (0x0, _0x5f425f['jsxs'])('p', {
                                    'className': _0x244184(0x188),
                                    'children': [_0x244184(0x168), '\x20', (0x0, _0x5f425f[_0x244184(0x145)])('strong', {
                                        'children': [null !== _0x1ed6ca && void 0x0 !== _0x1ed6ca && null !== (_0x47dbeb = _0x1ed6ca[_0x244184(0x135)]) && void 0x0 !== _0x47dbeb && _0x47dbeb['includes']('TL') ? _0x244184(0x1d5) : 'HR', '\x20', null === _0x1ed6ca || void 0x0 === _0x1ed6ca ? void 0x0 : _0x1ed6ca['name'][_0x244184(0x13c)]()]
                                    }), '\x20', _0x244184(0x142)]
                                }), null !== _0x1ed6ca && void 0x0 !== _0x1ed6ca && null !== (_0x18024d = _0x1ed6ca[_0x244184(0x135)]) && void 0x0 !== _0x18024d && _0x18024d[_0x244184(0x18a)]('HR') ? (0x0, _0x5f425f[_0x244184(0x145)])('ol', {
                                    'className': _0x244184(0x1d0),
                                    'children': [(0x0, _0x5f425f[_0x244184(0x145)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': [(0x0, _0x5f425f[_0x244184(0x1a5)])('strong', {
                                            'children': _0x244184(0x15b)
                                        }), _0x244184(0x159), '\x20', (0x0, _0x5f425f[_0x244184(0x1a5)])(_0x244184(0x147), {
                                            'children': null === _0x1ed6ca || void 0x0 === _0x1ed6ca ? void 0x0 : _0x1ed6ca[_0x244184(0x1dd)]
                                        }), '.']
                                    }), (0x0, _0x5f425f[_0x244184(0x145)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': [(0x0, _0x5f425f[_0x244184(0x1a5)])(_0x244184(0x147), {
                                            'children': 'Lead\x20Assignment:'
                                        }), _0x244184(0x158), (0x0, _0x5f425f['jsxs'])('strong', {
                                            'children': [null === _0x1ed6ca || void 0x0 === _0x1ed6ca ? void 0x0 : _0x1ed6ca['teamLeaderName'], '\x20']
                                        }), '.']
                                    }), (0x0, _0x5f425f[_0x244184(0x145)])('li', {
                                        'className': 'mb-2',
                                        'children': [(0x0, _0x5f425f[_0x244184(0x1a5)])('strong', {
                                            'children': _0x244184(0x18f)
                                        }), '\x20We\x20encourage\x20you\x20to\x20check\x20in\x20daily\x20to\x20view\x20and\x20manage\x20your\x20leads.\x20This\x20ensures\x20you\x20are\x20well-prepared\x20for\x20your\x20telecalling\x20activities\x20and\x20contributes\x20to\x20the\x20overall\x20success\x20of\x20the\x20team.\x20If\x20you\x20have\x20any\x20problems\x20or\x20inquiries,\x20don\x27t\x20hesitate\x20to\x20contact\x20your\x20team\x20leader,\x20', (0x0, _0x5f425f[_0x244184(0x145)])(_0x244184(0x147), {
                                            'children': [null === _0x1ed6ca || void 0x0 === _0x1ed6ca ? void 0x0 : _0x1ed6ca[_0x244184(0x1dd)], '\x20']
                                        }), '.']
                                    })]
                                }) : (0x0, _0x5f425f[_0x244184(0x145)])('ol', {
                                    'className': _0x244184(0x1d0),
                                    'children': [(0x0, _0x5f425f[_0x244184(0x1a5)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': 'Check\x20the\x20attendance\x20of\x20the\x20HR\x20team\x20and\x20address\x20any\x20delays\x20or\x20issues.'
                                    }), (0x0, _0x5f425f[_0x244184(0x1a5)])('li', {
                                        'className': 'mb-2',
                                        'children': _0x244184(0x134)
                                    }), (0x0, _0x5f425f[_0x244184(0x1a5)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': _0x244184(0x187)
                                    }), (0x0, _0x5f425f[_0x244184(0x1a5)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': _0x244184(0x131)
                                    }), (0x0, _0x5f425f[_0x244184(0x1a5)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': _0x244184(0x1b0)
                                    }), (0x0, _0x5f425f[_0x244184(0x1a5)])('li', {
                                        'className': _0x244184(0x184),
                                        'children': _0x244184(0x14f)
                                    })]
                                }), (0x0, _0x5f425f['jsxs'])('p', {
                                    'className': _0x244184(0x188),
                                    'children': ['❓\x20', (0x0, _0x5f425f['jsx'])(_0x244184(0x147), {
                                        'children': _0x244184(0x185)
                                    }), _0x244184(0x193)]
                                }), (0x0, _0x5f425f[_0x244184(0x1a5)])('p', {
                                    'className': _0x244184(0x1bd),
                                    'children': _0x244184(0x1cb)
                                }), (0x0, _0x5f425f['jsxs'])('p', {
                                    'className': _0x244184(0x12f),
                                    'children': [_0x244184(0x177), _0x3a721a['As']]
                                })]
                            })
                        }) : (0x0, _0x5f425f[_0x244184(0x145)])(_0x244184(0x1a9), {
                            'className': 'bg-base-100\x20\x20p-6\x20rounded-lg\x20shadow-lg',
                            'children': [(0x0, _0x5f425f[_0x244184(0x145)])('p', {
                                'className': _0x244184(0x13e),
                                'children': [_0x244184(0x14a), (0x0, _0x5f425f[_0x244184(0x145)])(_0x244184(0x147), {
                                    'children': [_0x3a721a['As'], '!']
                                }), _0x244184(0x1d2)]
                            }), (0x0, _0x5f425f[_0x244184(0x1a5)])('p', {
                                'className': _0x244184(0x188),
                                'children': _0x244184(0x173)
                            }), (0x0, _0x5f425f[_0x244184(0x145)])('ol', {
                                'className': _0x244184(0x1d0),
                                'children': [(0x0, _0x5f425f[_0x244184(0x145)])('li', {
                                    'className': _0x244184(0x184),
                                    'children': [(0x0, _0x5f425f['jsx'])('strong', {
                                        'children': _0x244184(0x15a)
                                    }), _0x244184(0x16e)]
                                }), (0x0, _0x5f425f[_0x244184(0x145)])('li', {
                                    'className': 'mb-2',
                                    'children': [(0x0, _0x5f425f[_0x244184(0x1a5)])(_0x244184(0x147), {
                                        'children': _0x244184(0x15f)
                                    }), '\x20We\x20understand\x20the\x20eagerness\x20to\x20get\x20started,\x20and\x20we\x20appreciate\x20your\x20patience\x20during\x20this\x20process.\x20Rest\x20assured\x20that\x20we\x20are\x20committed\x20to\x20expediting\x20the\x20verification\x20to\x20ensure\x20a\x20smooth\x20onboarding\x20experience\x20for\x20you.']
                                }), (0x0, _0x5f425f[_0x244184(0x145)])('li', {
                                    'className': _0x244184(0x184),
                                    'children': [(0x0, _0x5f425f[_0x244184(0x1a5)])(_0x244184(0x147), {
                                        'children': _0x244184(0x12c)
                                    }), _0x244184(0x1cc)]
                                })]
                            }), (0x0, _0x5f425f[_0x244184(0x1a5)])('br', {}), _0x244184(0x1c0)]
                        }) : (0x0, _0x5f425f[_0x244184(0x145)])(_0x5f425f['Fragment'], {
                            'children': [(0x0, _0x5f425f['jsxs'])('h1', {
                                'className': _0x244184(0x137),
                                'children': [_0x244184(0x1cf), _0x3a721a['As'], '!']
                            }), (0x0, _0x5f425f[_0x244184(0x1a5)])('p', {
                                'className': _0x244184(0x14d),
                                'children': _0x244184(0x180)
                            }), (0x0, _0x5f425f[_0x244184(0x145)])('p', {
                                'className': _0x244184(0x14d),
                                'children': ['Ready\x20to\x20boost\x20your\x20career?\x20Join\x20', _0x3a721a['As'], _0x244184(0x126)]
                            })]
                        })
                    });
                };
        },
        0x2202: function(_0x5b593f, _0x149ccd, _0x23dbf6) {
            function _0x50ca5f(_0x2a98e3) {
                var _0x574e43 = a42_0x2c5c;
                _0x2a98e3[_0x574e43(0x1a8)] && 0x199 === _0x2a98e3[_0x574e43(0x1a8)][_0x574e43(0x132)] ? (localStorage[_0x574e43(0x19a)](), window[_0x574e43(0x198)][_0x574e43(0x1c1)] = _0x574e43(0x19d)) : console[_0x574e43(0x14b)](_0x2a98e3);
            }
            _0x23dbf6['d'](_0x149ccd, {
                'S': function() {
                    return _0x50ca5f;
                }
            });
        },
        0x1647: function(_0x72fd6, _0x43002f, _0x17d5e1) {
            var _0x18f2e7 = a42_0x5aef4c,
                _0x203348 = _0x17d5e1(0x1763),
                _0x533641 = _0x17d5e1(0x1c91),
                _0x2b8766 = ['title', _0x18f2e7(0x133)],
                _0x30f5fb = _0x533641['forwardRef'](function(_0xdb6c83, _0x2ae978) {
                    var _0x5d853e = _0x18f2e7,
                        _0x2bb5d8 = _0xdb6c83['title'],
                        _0x2139c2 = _0xdb6c83[_0x5d853e(0x133)],
                        _0x2203de = (0x0, _0x203348['Z'])(_0xdb6c83, _0x2b8766);
                    return _0x533641[_0x5d853e(0x1bb)](_0x5d853e(0x18b), Object[_0x5d853e(0x155)]({
                        'xmlns': _0x5d853e(0x12d),
                        'fill': 'none',
                        'viewBox': _0x5d853e(0x1ad),
                        'strokeWidth': 1.5,
                        'stroke': _0x5d853e(0x1ac),
                        'aria-hidden': _0x5d853e(0x1ae),
                        'ref': _0x2ae978,
                        'aria-labelledby': _0x2139c2
                    }, _0x2203de), _0x2bb5d8 ? _0x533641[_0x5d853e(0x1bb)](_0x5d853e(0x174), {
                        'id': _0x2139c2
                    }, _0x2bb5d8) : null, _0x533641[_0x5d853e(0x1bb)](_0x5d853e(0x16b), {
                        'strokeLinecap': _0x5d853e(0x1d8),
                        'strokeLinejoin': _0x5d853e(0x1d8),
                        'd': _0x5d853e(0x152)
                    }), _0x533641['createElement'](_0x5d853e(0x16b), {
                        'strokeLinecap': _0x5d853e(0x1d8),
                        'strokeLinejoin': 'round',
                        'd': _0x5d853e(0x1d9)
                    }));
                });
            _0x43002f['Z'] = _0x30f5fb;
        },
        0x1203: function(_0x19811b, _0x4557f1, _0x33b722) {
            var _0xf95c7b = a42_0x5aef4c,
                _0x5e3b7b = _0x33b722(0x1763),
                _0x23b091 = _0x33b722(0x1c91),
                _0x45bb68 = [_0xf95c7b(0x174), _0xf95c7b(0x133)],
                _0x3b3bad = _0x23b091[_0xf95c7b(0x192)](function(_0x535f02, _0x35de26) {
                    var _0x65fd15 = _0xf95c7b,
                        _0x2b0606 = _0x535f02[_0x65fd15(0x174)],
                        _0x5b3359 = _0x535f02[_0x65fd15(0x133)],
                        _0x5b117d = (0x0, _0x5e3b7b['Z'])(_0x535f02, _0x45bb68);
                    return _0x23b091['createElement'](_0x65fd15(0x18b), Object['assign']({
                        'xmlns': _0x65fd15(0x12d),
                        'fill': _0x65fd15(0x160),
                        'viewBox': _0x65fd15(0x1ad),
                        'strokeWidth': 1.5,
                        'stroke': _0x65fd15(0x1ac),
                        'aria-hidden': _0x65fd15(0x1ae),
                        'ref': _0x35de26,
                        'aria-labelledby': _0x5b3359
                    }, _0x5b117d), _0x2b0606 ? _0x23b091[_0x65fd15(0x1bb)](_0x65fd15(0x174), {
                        'id': _0x5b3359
                    }, _0x2b0606) : null, _0x23b091[_0x65fd15(0x1bb)](_0x65fd15(0x16b), {
                        'strokeLinecap': _0x65fd15(0x1d8),
                        'strokeLinejoin': _0x65fd15(0x1d8),
                        'd': _0x65fd15(0x138)
                    }));
                });
            _0x4557f1['Z'] = _0x3b3bad;
        }
    }
]);